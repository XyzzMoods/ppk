module.exports = {
  tokens: "8395857624:AAF4RjBwkAUA262_n9pgmUKHZ90Wm7S-xOk",
  owner: "8149953533",
  port: "4102",
  ipvps: "139.59.5.72"
};